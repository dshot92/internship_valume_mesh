=============== Graphite /// ================


This is a binary distribution of Graphite

To start Graphite, click on graphite.bat (nothing to "install" !)

The Graphite executable is in GraphiteThree/bin/win64/graphite.exe
(you may create a shortcut to it on the desktop)

The documentation is online, see:
   http://alice.loria.fr/software/graphite/doc/html/


Troubleshooting:
----------------

If you got an error message about missing MSVCP???.dll or missing
VCRUNTIME???.dll, then you'll need to install a small package (a few
megabytes):
   Visual C++ 2017 redistribuable package (x64)
(can be obtained from www.microsoft.com, just google it)

 

